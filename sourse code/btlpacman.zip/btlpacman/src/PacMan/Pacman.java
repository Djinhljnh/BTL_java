package PacMan;


import Authen.authenCationJDialog;
import javax.swing.JFrame;

public class Pacman extends JFrame{
    public static void main(String[] args) {
        new authenCationJDialog();
    }

}