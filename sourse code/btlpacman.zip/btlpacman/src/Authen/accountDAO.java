package Authen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;


/**
 *
 * @author dinhl
 */
public class accountDAO {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/pacman";
    private static final String user = "root";
    private static final String password = "";

    // tra ve kn datab
    public Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(DB_URL, user, password);
            return conn;
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public account login(String userName, String Password) throws SQLException {
        try (Connection conn = getConnection(); PreparedStatement ps
                = conn.prepareStatement("SELECT * FROM account WHERE user_name = ? AND password = ?");) {
            ps.setString(1, userName);
            ps.setString(2, Password);
            try (ResultSet rs = ps.executeQuery()) { // truy van den csdl de lay tu bang account roi luu vao réul
                if (rs.next()) {
                    account account = new account();

                    // Lấy dữ liệu từ ResultSet và gán cho đối tượng account
                    account.setAccountCode(rs.getInt("account_code"));
                    account.setUserName(rs.getString("user_name"));
                    account.setPassword(rs.getString("password"));
                    account.setStatus(rs.getBoolean("status"));
                    int highestScore = rs.getInt("highest_score");
                    if (rs.wasNull()) {
                        account.setHigestScore(0);
                    } else {
                        account.setHigestScore(highestScore);
                    }
                    return account;

                }
            } catch (SQLException e) {
                System.out.println(e);
            }
            return null;
        }

    }

    public boolean isUsernameExist(String username) {
        //khai bao 3 bien
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = getConnection(); // sd phg thuc getconnection

            String sql = "SELECT COUNT(*) AS count FROM account WHERE user_name = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, username);//thay the tham so 1 cua sql ? bang username
            rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt("count");
                if (count > 0) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("Lỗi truy vấn tài khoản");
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("Lỗi đóng kết nối");
            }
        }
        return false;
    }

    public boolean register(account account) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean result = false;

        try {
            conn = getConnection();
            String sql = "INSERT INTO account (user_name, password, status) VALUES (?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, account.getUserName());
            ps.setString(2, account.getPassword());
            ps.setBoolean(3, account.isStatus());
            int rows = ps.executeUpdate(); //thuc hien cau lenh sql tren 
            if (rows > 0) {
                result = true;
            }
        } catch (SQLException e) {
            System.out.println("loi tao tai khoan");
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("loi dong ket noi");
            }
        }
        return result;
    }

    public void updateScore(int score, int accountCode) throws SQLException {
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement("UPDATE account SET highest_score = ? WHERE account_code = ?")) {
            ps.setInt(1, score);
            ps.setInt(2, accountCode);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("diem so da duoc cap nhat thanh cong.");
            } else {
                System.out.println("khong tim thay tai khoan nao co ma tuong ung.");
            }
        } catch (SQLException e) {
            System.out.println("loi khi cap nhat diem so: " + e.getMessage());
        }
    }

}
