/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Authen;

import static Authen.authenCationController.authencationJPanel;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author dinhl
 */
public class formRegisterController {

    private final JTextField jtfUserName;
    private final JPasswordField jpfPassword;
    private final JPasswordField jpfComfirmPassword;
    private final JLabel jlbErrMsg;
    private final JButton btnSubmit;
    private final JButton btnReset;
    private final JButton btnLogin;
    private accountDAO accountDAO;

    public formRegisterController(JTextField jtfUserName, JPasswordField jpfPassword, JPasswordField jpfComfirmPassword, JLabel jlbErrMsg, JButton btnSubmit, JButton btnReset, JButton btnSignUp) {
        this.jtfUserName = jtfUserName;
        this.jpfPassword = jpfPassword;
        this.jpfComfirmPassword = jpfComfirmPassword;
        this.jlbErrMsg = jlbErrMsg;
        this.btnSubmit = btnSubmit;
        this.btnReset = btnReset;
        this.btnLogin = btnSignUp;
        this.accountDAO = new accountDAO();
    }

    public void setEvent() {
        btnReset.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jtfUserName.setText("");
                jpfPassword.setText("");
                jpfComfirmPassword.setText("");
            }
        });
        btnLogin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JPanel node = new formLoginJPanel();
                authencationJPanel.removeAll();
                authencationJPanel.setLayout(new BorderLayout());
                authencationJPanel.add(node, BorderLayout.CENTER);
                authencationJPanel.validate();
                authencationJPanel.repaint();
            }
        });

        btnSubmit.addMouseListener(new MouseAdapter() {

            public void mouseClicked(MouseEvent e) {
                //chuyen ve string
                String password = new String(jpfPassword.getPassword());
                String comfirmPassword = new String(jpfComfirmPassword.getPassword());
                try {
                    // nhap du cac o
                    if (jtfUserName.getText().length() == 0
                            || password.length() == 0
                            || comfirmPassword.length() == 0) {
                        jlbErrMsg.setText("Please enter required data");
                    } else {
                        //kiem tra ten co phai 1 email dung 
                        if (!jtfUserName.getText().matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
                            jlbErrMsg.setText("Username must be email.");
                        } else if (!jtfUserName.getText().matches("^\\S+$")) { // chua khoang tran
                            jlbErrMsg.setText("Username must not contain any whitespace.");
                        } else if (accountDAO.isUsernameExist(jtfUserName.getText())) { // da ton tai chua
                            jlbErrMsg.setText("The account name already exists on the system");
                        } else if (!password.matches("^\\S{6,}$")) {//co it nhat 6 ki tu
                            jlbErrMsg.setText("Password must be at least 6 characters long ");
                        } else if (!password.equals(comfirmPassword)) {// mk trung nhap lại mk
                            jlbErrMsg.setText("Password re-enter mismatch");
                        } else {
                            account account = new account();
                            account.setUserName(jtfUserName.getText());
                            account.setPassword(password);
                            account.setStatus(true);
                            accountDAO.register(account);
                            jlbErrMsg.setText("Successful registration");

                        }
                    }
                } catch (Exception ex) {
                    System.out.println(ex.toString());
                    jlbErrMsg.setText("Connection error");
                }
            }

        });
    }

}
