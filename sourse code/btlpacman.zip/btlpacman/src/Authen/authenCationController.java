package Authen;

import java.awt.BorderLayout;
import javax.swing.JDialog;
import javax.swing.JPanel;
//quan li hien thi dang nhap
public class authenCationController {
    // luu tru tham chieu den
    public static JDialog authencationJDialog;
    public static JPanel authencationJPanel;

    public authenCationController(JDialog AuthencationJDialog, JPanel AuthencationJPanel) {
        authenCationController.authencationJDialog = AuthencationJDialog;
        authenCationController.authencationJPanel = AuthencationJPanel;
    }

    public void renderMUI() {
        JPanel node = new formLoginJPanel();
        authencationJPanel.removeAll();
        authencationJPanel.setLayout(new BorderLayout());
        authencationJPanel.add(node, BorderLayout.CENTER);
        authencationJPanel.validate();
        authencationJPanel.repaint();
    }
    
    
}
