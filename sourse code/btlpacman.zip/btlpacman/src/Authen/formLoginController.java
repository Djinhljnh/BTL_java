/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Authen;

import static Authen.authenCationController.authencationJPanel;
import static Authen.authenCationController.authencationJDialog;
import PacMan.Board;
import PacMan.Pacman;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class formLoginController {

    private final JTextField jtfUserName;
    private final JPasswordField jpfPassword;
    private final JLabel jlbErrMsg;
    private final JButton btnSubmit;
    private final JButton btnReset;
    private final JButton btnSignUp;
    public static account authenticated_account;
    private accountDAO accountDAO;

    public formLoginController(JTextField jtfUserName, JPasswordField jtfPassword, JLabel jlbErrMsg,
            JButton btnSubmit, JButton btnReset, JButton btnSignUp) {
        this.jtfUserName = jtfUserName;
        this.jpfPassword = jtfPassword;
        this.jlbErrMsg = jlbErrMsg;
        this.btnSubmit = btnSubmit;
        this.btnReset = btnReset;
        this.btnSignUp = btnSignUp;
        this.accountDAO = new accountDAO();
    }

    public void setEvent() {
        btnReset.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jtfUserName.setText("");
                jpfPassword.setText("");
            }
        });
        btnSignUp.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JPanel node = new formRegisterJPanel();
                authencationJPanel.removeAll();
                authencationJPanel.setLayout(new BorderLayout());
                authencationJPanel.add(node, BorderLayout.CENTER);
                authencationJPanel.validate();
                authencationJPanel.repaint();
            }
        });
        btnSubmit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    //doi kieu tu chả sang string
                    String password = new String(jpfPassword.getPassword());
                    //nhap du thong tin chua
                    if (jtfUserName.getText().length() == 0
                            || password.length() == 0) {
                        jlbErrMsg.setText("Please enter required data");
                    } else {
                        //goi den login cua dao kt dang nhap
                        authenticated_account = accountDAO.login(jtfUserName.getText(), password);
                        if (authenticated_account == null) {//dang nhap thanh cong ko
                            jlbErrMsg.setText("Username and password are incorrect");
                        } else {
                            if (!authenticated_account.isStatus()) {//tai khoan có bị khoa ko, bị thi inn ra thg bao
                                jlbErrMsg.setText("Your account is temporarily locked");
                            } else {
                                authencationJDialog.dispose(); //dong dang nhap
                                JFrame game = new JFrame();
                                game.add(new Board());
                                game.setVisible(true);
                                game.setTitle("Pacman");
                                game.setSize(380, 420);
                                game.setDefaultCloseOperation(EXIT_ON_CLOSE);
                                game.setLocationRelativeTo(null);
                            }
                        }
                    }
                } catch (Exception ex) {
                    jlbErrMsg.setText("Connection error");
                }
            }
        });
    }
}
